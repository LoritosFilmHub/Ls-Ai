import React, { useState } from "react";
import Layout from "./components/Layout";
import FormatSelector from "./components/FormatSelector";
import ImageCountSelector from "./components/ImageCountSelector";
import ImageCard from "./components/ImageCard";
import DonationButton from "./components/DonationButton";
import DonationModal from "./components/DonationModal";
import ImagePreviewModal from "./components/ImagePreviewModal";

export default function App() {
  const [selectedFormat, setSelectedFormat] = useState("square image, 1:1 aspect ratio");
  const [imageCount, setImageCount] = useState(1);
  const [copiedUrl, setCopiedUrl] = useState(null);
  const [isDonationOpen, setDonationOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);

  const images = [
    { title: "Exemplo Imagem 1", image_url: "https://picsum.photos/400/300?1" },
    { title: "Exemplo Imagem 2", image_url: "https://picsum.photos/400/300?2" }
  ];

  const handleCopy = async (url) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      setTimeout(() => setCopiedUrl(null), 2000);
    } catch (err) {
      console.error("Erro ao copiar:", err);
    }
  };

  const handleDownload = (url) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = "image.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Layout>
      <div className="p-6 space-y-6 text-center">
        <h1 className="text-3xl font-bold text-white">🚀 Minha Plataforma AI</h1>
        <FormatSelector selectedFormat={selectedFormat} onFormatChange={setSelectedFormat} />
        <ImageCountSelector imageCount={imageCount} onImageCountChange={setImageCount} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          {images.map((image) => (
            <ImageCard
              key={image.title}
              image={image}
              onCopy={handleCopy}
              onDownload={handleDownload}
              isCopied={copiedUrl === image.image_url}
              onImageClick={setPreviewImage}
            />
          ))}
        </div>
      </div>
      <DonationButton onClick={() => setDonationOpen(true)} />
      <DonationModal isOpen={isDonationOpen} onClose={() => setDonationOpen(false)} />
      <ImagePreviewModal isOpen={!!previewImage} onClose={() => setPreviewImage(null)} image={previewImage} onDownload={handleDownload} />
    </Layout>
  );
}